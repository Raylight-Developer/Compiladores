# Generated from Compiscript.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,48,345,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,1,0,5,0,72,8,0,10,0,12,0,75,9,0,1,0,1,0,1,1,1,1,1,
        1,1,1,3,1,83,8,1,1,2,1,2,1,2,1,2,3,2,89,8,2,1,2,1,2,1,2,1,2,1,3,
        5,3,96,8,3,10,3,12,3,99,9,3,1,4,1,4,1,5,1,5,1,5,1,6,1,6,1,6,1,7,
        1,7,1,7,1,7,1,7,1,7,1,7,3,7,116,8,7,1,8,1,8,1,8,1,9,1,9,1,9,1,9,
        1,9,3,9,126,8,9,1,9,3,9,129,8,9,1,9,1,9,3,9,133,8,9,1,9,1,9,1,9,
        1,10,1,10,1,10,1,10,1,10,1,10,1,10,3,10,145,8,10,1,11,1,11,1,11,
        1,11,1,12,1,12,3,12,153,8,12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,
        1,13,1,14,1,14,5,14,165,8,14,10,14,12,14,168,9,14,1,14,1,14,1,15,
        1,15,1,15,3,15,175,8,15,1,15,1,15,1,15,1,16,1,16,3,16,182,8,16,1,
        17,1,17,1,17,3,17,187,8,17,1,17,1,17,1,17,1,17,3,17,193,8,17,1,18,
        1,18,1,18,5,18,198,8,18,10,18,12,18,201,9,18,1,19,1,19,1,19,5,19,
        206,8,19,10,19,12,19,209,9,19,1,20,1,20,1,20,5,20,214,8,20,10,20,
        12,20,217,9,20,1,21,1,21,1,21,5,21,222,8,21,10,21,12,21,225,9,21,
        1,22,1,22,1,22,5,22,230,8,22,10,22,12,22,233,9,22,1,23,1,23,1,23,
        5,23,238,8,23,10,23,12,23,241,9,23,1,24,1,24,1,24,1,24,5,24,247,
        8,24,10,24,12,24,250,9,24,3,24,252,8,24,1,24,1,24,1,25,1,25,1,25,
        1,25,3,25,260,8,25,1,25,1,25,1,26,1,26,1,26,3,26,267,8,26,1,27,1,
        27,5,27,271,8,27,10,27,12,27,274,9,27,1,27,3,27,277,8,27,1,28,1,
        28,1,28,1,28,3,28,283,8,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,3,
        28,292,8,28,1,29,1,29,1,29,1,29,1,30,1,30,1,30,1,30,1,30,1,30,1,
        30,1,30,1,30,1,30,1,30,1,30,1,30,1,30,3,30,312,8,30,1,31,1,31,1,
        31,3,31,317,8,31,1,31,1,31,1,31,1,32,1,32,1,32,3,32,325,8,32,1,32,
        1,32,1,33,1,33,1,33,5,33,332,8,33,10,33,12,33,335,9,33,1,34,1,34,
        1,34,5,34,340,8,34,10,34,12,34,343,9,34,1,34,0,0,35,0,2,4,6,8,10,
        12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,
        56,58,60,62,64,66,68,0,7,1,0,18,19,1,0,20,21,1,0,22,23,1,0,24,27,
        1,0,28,29,1,0,30,32,2,0,28,28,37,37,362,0,73,1,0,0,0,2,82,1,0,0,
        0,4,84,1,0,0,0,6,97,1,0,0,0,8,100,1,0,0,0,10,102,1,0,0,0,12,105,
        1,0,0,0,14,115,1,0,0,0,16,117,1,0,0,0,18,120,1,0,0,0,20,137,1,0,
        0,0,22,146,1,0,0,0,24,150,1,0,0,0,26,156,1,0,0,0,28,162,1,0,0,0,
        30,171,1,0,0,0,32,181,1,0,0,0,34,192,1,0,0,0,36,194,1,0,0,0,38,202,
        1,0,0,0,40,210,1,0,0,0,42,218,1,0,0,0,44,226,1,0,0,0,46,234,1,0,
        0,0,48,242,1,0,0,0,50,255,1,0,0,0,52,266,1,0,0,0,54,276,1,0,0,0,
        56,291,1,0,0,0,58,293,1,0,0,0,60,311,1,0,0,0,62,313,1,0,0,0,64,321,
        1,0,0,0,66,328,1,0,0,0,68,336,1,0,0,0,70,72,3,2,1,0,71,70,1,0,0,
        0,72,75,1,0,0,0,73,71,1,0,0,0,73,74,1,0,0,0,74,76,1,0,0,0,75,73,
        1,0,0,0,76,77,5,0,0,1,77,1,1,0,0,0,78,83,3,4,2,0,79,83,3,10,5,0,
        80,83,3,12,6,0,81,83,3,14,7,0,82,78,1,0,0,0,82,79,1,0,0,0,82,80,
        1,0,0,0,82,81,1,0,0,0,83,3,1,0,0,0,84,85,5,1,0,0,85,88,5,45,0,0,
        86,87,5,2,0,0,87,89,5,45,0,0,88,86,1,0,0,0,88,89,1,0,0,0,89,90,1,
        0,0,0,90,91,5,3,0,0,91,92,3,6,3,0,92,93,5,4,0,0,93,5,1,0,0,0,94,
        96,3,8,4,0,95,94,1,0,0,0,96,99,1,0,0,0,97,95,1,0,0,0,97,98,1,0,0,
        0,98,7,1,0,0,0,99,97,1,0,0,0,100,101,3,62,31,0,101,9,1,0,0,0,102,
        103,5,5,0,0,103,104,3,62,31,0,104,11,1,0,0,0,105,106,5,6,0,0,106,
        107,3,64,32,0,107,13,1,0,0,0,108,116,3,16,8,0,109,116,3,18,9,0,110,
        116,3,20,10,0,111,116,3,22,11,0,112,116,3,24,12,0,113,116,3,26,13,
        0,114,116,3,28,14,0,115,108,1,0,0,0,115,109,1,0,0,0,115,110,1,0,
        0,0,115,111,1,0,0,0,115,112,1,0,0,0,115,113,1,0,0,0,115,114,1,0,
        0,0,116,15,1,0,0,0,117,118,3,32,16,0,118,119,5,7,0,0,119,17,1,0,
        0,0,120,121,5,8,0,0,121,125,5,9,0,0,122,126,3,12,6,0,123,126,3,16,
        8,0,124,126,5,7,0,0,125,122,1,0,0,0,125,123,1,0,0,0,125,124,1,0,
        0,0,126,128,1,0,0,0,127,129,3,32,16,0,128,127,1,0,0,0,128,129,1,
        0,0,0,129,130,1,0,0,0,130,132,5,7,0,0,131,133,3,32,16,0,132,131,
        1,0,0,0,132,133,1,0,0,0,133,134,1,0,0,0,134,135,5,10,0,0,135,136,
        3,14,7,0,136,19,1,0,0,0,137,138,5,11,0,0,138,139,5,9,0,0,139,140,
        3,32,16,0,140,141,5,10,0,0,141,144,3,14,7,0,142,143,5,12,0,0,143,
        145,3,14,7,0,144,142,1,0,0,0,144,145,1,0,0,0,145,21,1,0,0,0,146,
        147,5,13,0,0,147,148,3,32,16,0,148,149,5,7,0,0,149,23,1,0,0,0,150,
        152,5,14,0,0,151,153,3,32,16,0,152,151,1,0,0,0,152,153,1,0,0,0,153,
        154,1,0,0,0,154,155,5,7,0,0,155,25,1,0,0,0,156,157,5,15,0,0,157,
        158,5,9,0,0,158,159,3,32,16,0,159,160,5,10,0,0,160,161,3,14,7,0,
        161,27,1,0,0,0,162,166,5,3,0,0,163,165,3,2,1,0,164,163,1,0,0,0,165,
        168,1,0,0,0,166,164,1,0,0,0,166,167,1,0,0,0,167,169,1,0,0,0,168,
        166,1,0,0,0,169,170,5,4,0,0,170,29,1,0,0,0,171,172,5,5,0,0,172,174,
        5,9,0,0,173,175,3,66,33,0,174,173,1,0,0,0,174,175,1,0,0,0,175,176,
        1,0,0,0,176,177,5,10,0,0,177,178,3,28,14,0,178,31,1,0,0,0,179,182,
        3,34,17,0,180,182,3,30,15,0,181,179,1,0,0,0,181,180,1,0,0,0,182,
        33,1,0,0,0,183,184,3,54,27,0,184,185,5,16,0,0,185,187,1,0,0,0,186,
        183,1,0,0,0,186,187,1,0,0,0,187,188,1,0,0,0,188,189,5,45,0,0,189,
        190,5,17,0,0,190,193,3,34,17,0,191,193,3,36,18,0,192,186,1,0,0,0,
        192,191,1,0,0,0,193,35,1,0,0,0,194,199,3,38,19,0,195,196,7,0,0,0,
        196,198,3,38,19,0,197,195,1,0,0,0,198,201,1,0,0,0,199,197,1,0,0,
        0,199,200,1,0,0,0,200,37,1,0,0,0,201,199,1,0,0,0,202,207,3,40,20,
        0,203,204,7,1,0,0,204,206,3,40,20,0,205,203,1,0,0,0,206,209,1,0,
        0,0,207,205,1,0,0,0,207,208,1,0,0,0,208,39,1,0,0,0,209,207,1,0,0,
        0,210,215,3,42,21,0,211,212,7,2,0,0,212,214,3,42,21,0,213,211,1,
        0,0,0,214,217,1,0,0,0,215,213,1,0,0,0,215,216,1,0,0,0,216,41,1,0,
        0,0,217,215,1,0,0,0,218,223,3,44,22,0,219,220,7,3,0,0,220,222,3,
        44,22,0,221,219,1,0,0,0,222,225,1,0,0,0,223,221,1,0,0,0,223,224,
        1,0,0,0,224,43,1,0,0,0,225,223,1,0,0,0,226,231,3,46,23,0,227,228,
        7,4,0,0,228,230,3,46,23,0,229,227,1,0,0,0,230,233,1,0,0,0,231,229,
        1,0,0,0,231,232,1,0,0,0,232,45,1,0,0,0,233,231,1,0,0,0,234,239,3,
        52,26,0,235,236,7,5,0,0,236,238,3,52,26,0,237,235,1,0,0,0,238,241,
        1,0,0,0,239,237,1,0,0,0,239,240,1,0,0,0,240,47,1,0,0,0,241,239,1,
        0,0,0,242,251,5,33,0,0,243,248,3,32,16,0,244,245,5,34,0,0,245,247,
        3,32,16,0,246,244,1,0,0,0,247,250,1,0,0,0,248,246,1,0,0,0,248,249,
        1,0,0,0,249,252,1,0,0,0,250,248,1,0,0,0,251,243,1,0,0,0,251,252,
        1,0,0,0,252,253,1,0,0,0,253,254,5,35,0,0,254,49,1,0,0,0,255,256,
        5,36,0,0,256,257,5,45,0,0,257,259,5,9,0,0,258,260,3,68,34,0,259,
        258,1,0,0,0,259,260,1,0,0,0,260,261,1,0,0,0,261,262,5,10,0,0,262,
        51,1,0,0,0,263,264,7,6,0,0,264,267,3,52,26,0,265,267,3,54,27,0,266,
        263,1,0,0,0,266,265,1,0,0,0,267,53,1,0,0,0,268,272,3,60,30,0,269,
        271,3,56,28,0,270,269,1,0,0,0,271,274,1,0,0,0,272,270,1,0,0,0,272,
        273,1,0,0,0,273,277,1,0,0,0,274,272,1,0,0,0,275,277,3,30,15,0,276,
        268,1,0,0,0,276,275,1,0,0,0,277,55,1,0,0,0,278,279,5,9,0,0,279,292,
        5,10,0,0,280,282,5,9,0,0,281,283,3,68,34,0,282,281,1,0,0,0,282,283,
        1,0,0,0,283,284,1,0,0,0,284,292,5,10,0,0,285,286,5,16,0,0,286,292,
        5,45,0,0,287,288,5,33,0,0,288,289,3,32,16,0,289,290,5,35,0,0,290,
        292,1,0,0,0,291,278,1,0,0,0,291,280,1,0,0,0,291,285,1,0,0,0,291,
        287,1,0,0,0,292,57,1,0,0,0,293,294,5,38,0,0,294,295,5,16,0,0,295,
        296,5,45,0,0,296,59,1,0,0,0,297,312,5,39,0,0,298,312,5,40,0,0,299,
        312,5,41,0,0,300,312,5,42,0,0,301,312,5,43,0,0,302,312,5,44,0,0,
        303,312,5,45,0,0,304,305,5,9,0,0,305,306,3,32,16,0,306,307,5,10,
        0,0,307,312,1,0,0,0,308,312,3,58,29,0,309,312,3,48,24,0,310,312,
        3,50,25,0,311,297,1,0,0,0,311,298,1,0,0,0,311,299,1,0,0,0,311,300,
        1,0,0,0,311,301,1,0,0,0,311,302,1,0,0,0,311,303,1,0,0,0,311,304,
        1,0,0,0,311,308,1,0,0,0,311,309,1,0,0,0,311,310,1,0,0,0,312,61,1,
        0,0,0,313,314,5,45,0,0,314,316,5,9,0,0,315,317,3,66,33,0,316,315,
        1,0,0,0,316,317,1,0,0,0,317,318,1,0,0,0,318,319,5,10,0,0,319,320,
        3,28,14,0,320,63,1,0,0,0,321,324,5,45,0,0,322,323,5,17,0,0,323,325,
        3,32,16,0,324,322,1,0,0,0,324,325,1,0,0,0,325,326,1,0,0,0,326,327,
        5,7,0,0,327,65,1,0,0,0,328,333,5,45,0,0,329,330,5,34,0,0,330,332,
        5,45,0,0,331,329,1,0,0,0,332,335,1,0,0,0,333,331,1,0,0,0,333,334,
        1,0,0,0,334,67,1,0,0,0,335,333,1,0,0,0,336,341,3,32,16,0,337,338,
        5,34,0,0,338,340,3,32,16,0,339,337,1,0,0,0,340,343,1,0,0,0,341,339,
        1,0,0,0,341,342,1,0,0,0,342,69,1,0,0,0,343,341,1,0,0,0,34,73,82,
        88,97,115,125,128,132,144,152,166,174,181,186,192,199,207,215,223,
        231,239,248,251,259,266,272,276,282,291,311,316,324,333,341
    ]

class CompiscriptParser ( Parser ):

    grammarFileName = "Compiscript.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'class'", "'extends'", "'{'", "'}'", 
                     "'fun'", "'var'", "';'", "'for'", "'('", "')'", "'if'", 
                     "'else'", "'print'", "'return'", "'while'", "'.'", 
                     "'='", "'or'", "'||'", "'and'", "'&&'", "'!='", "'=='", 
                     "'>'", "'>='", "'<'", "'<='", "'-'", "'+'", "'/'", 
                     "'*'", "'%'", "'['", "','", "']'", "'new'", "'!'", 
                     "'super'", "'true'", "'false'", "'nil'", "'this'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "NUMBER", "STRING", 
                      "IDENTIFIER", "WS", "ONE_LINE_COMMENT", "MULTI_LINE_COMMENT" ]

    RULE_program = 0
    RULE_declaration = 1
    RULE_classDecl = 2
    RULE_classBody = 3
    RULE_classMember = 4
    RULE_funDecl = 5
    RULE_varDecl = 6
    RULE_statement = 7
    RULE_exprStmt = 8
    RULE_forStmt = 9
    RULE_ifStmt = 10
    RULE_printStmt = 11
    RULE_returnStmt = 12
    RULE_whileStmt = 13
    RULE_block = 14
    RULE_funAnon = 15
    RULE_expression = 16
    RULE_assignment = 17
    RULE_logic_or = 18
    RULE_logic_and = 19
    RULE_equality = 20
    RULE_comparison = 21
    RULE_term = 22
    RULE_factor = 23
    RULE_array = 24
    RULE_instantiation = 25
    RULE_unary = 26
    RULE_call = 27
    RULE_callSuffix = 28
    RULE_superCall = 29
    RULE_primary = 30
    RULE_function = 31
    RULE_variable = 32
    RULE_parameters = 33
    RULE_arguments = 34

    ruleNames =  [ "program", "declaration", "classDecl", "classBody", "classMember", 
                   "funDecl", "varDecl", "statement", "exprStmt", "forStmt", 
                   "ifStmt", "printStmt", "returnStmt", "whileStmt", "block", 
                   "funAnon", "expression", "assignment", "logic_or", "logic_and", 
                   "equality", "comparison", "term", "factor", "array", 
                   "instantiation", "unary", "call", "callSuffix", "superCall", 
                   "primary", "function", "variable", "parameters", "arguments" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    T__34=35
    T__35=36
    T__36=37
    T__37=38
    T__38=39
    T__39=40
    T__40=41
    T__41=42
    NUMBER=43
    STRING=44
    IDENTIFIER=45
    WS=46
    ONE_LINE_COMMENT=47
    MULTI_LINE_COMMENT=48

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(CompiscriptParser.EOF, 0)

        def declaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.DeclarationContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.DeclarationContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = CompiscriptParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 73
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 70308883131242) != 0):
                self.state = 70
                self.declaration()
                self.state = 75
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 76
            self.match(CompiscriptParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def classDecl(self):
            return self.getTypedRuleContext(CompiscriptParser.ClassDeclContext,0)


        def funDecl(self):
            return self.getTypedRuleContext(CompiscriptParser.FunDeclContext,0)


        def varDecl(self):
            return self.getTypedRuleContext(CompiscriptParser.VarDeclContext,0)


        def statement(self):
            return self.getTypedRuleContext(CompiscriptParser.StatementContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_declaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaration" ):
                listener.enterDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaration" ):
                listener.exitDeclaration(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclaration" ):
                return visitor.visitDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def declaration(self):

        localctx = CompiscriptParser.DeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_declaration)
        try:
            self.state = 82
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 78
                self.classDecl()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 79
                self.funDecl()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 80
                self.varDecl()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 81
                self.statement()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self, i:int=None):
            if i is None:
                return self.getTokens(CompiscriptParser.IDENTIFIER)
            else:
                return self.getToken(CompiscriptParser.IDENTIFIER, i)

        def classBody(self):
            return self.getTypedRuleContext(CompiscriptParser.ClassBodyContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_classDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClassDecl" ):
                listener.enterClassDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClassDecl" ):
                listener.exitClassDecl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitClassDecl" ):
                return visitor.visitClassDecl(self)
            else:
                return visitor.visitChildren(self)




    def classDecl(self):

        localctx = CompiscriptParser.ClassDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_classDecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 84
            self.match(CompiscriptParser.T__0)
            self.state = 85
            self.match(CompiscriptParser.IDENTIFIER)
            self.state = 88
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==2:
                self.state = 86
                self.match(CompiscriptParser.T__1)
                self.state = 87
                self.match(CompiscriptParser.IDENTIFIER)


            self.state = 90
            self.match(CompiscriptParser.T__2)
            self.state = 91
            self.classBody()
            self.state = 92
            self.match(CompiscriptParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassBodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def classMember(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ClassMemberContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ClassMemberContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_classBody

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClassBody" ):
                listener.enterClassBody(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClassBody" ):
                listener.exitClassBody(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitClassBody" ):
                return visitor.visitClassBody(self)
            else:
                return visitor.visitChildren(self)




    def classBody(self):

        localctx = CompiscriptParser.ClassBodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_classBody)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 97
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==45:
                self.state = 94
                self.classMember()
                self.state = 99
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassMemberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function(self):
            return self.getTypedRuleContext(CompiscriptParser.FunctionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_classMember

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClassMember" ):
                listener.enterClassMember(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClassMember" ):
                listener.exitClassMember(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitClassMember" ):
                return visitor.visitClassMember(self)
            else:
                return visitor.visitChildren(self)




    def classMember(self):

        localctx = CompiscriptParser.ClassMemberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_classMember)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 100
            self.function()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function(self):
            return self.getTypedRuleContext(CompiscriptParser.FunctionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_funDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunDecl" ):
                listener.enterFunDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunDecl" ):
                listener.exitFunDecl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunDecl" ):
                return visitor.visitFunDecl(self)
            else:
                return visitor.visitChildren(self)




    def funDecl(self):

        localctx = CompiscriptParser.FunDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_funDecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            self.match(CompiscriptParser.T__4)
            self.state = 103
            self.function()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VarDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable(self):
            return self.getTypedRuleContext(CompiscriptParser.VariableContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_varDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarDecl" ):
                listener.enterVarDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarDecl" ):
                listener.exitVarDecl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarDecl" ):
                return visitor.visitVarDecl(self)
            else:
                return visitor.visitChildren(self)




    def varDecl(self):

        localctx = CompiscriptParser.VarDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_varDecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 105
            self.match(CompiscriptParser.T__5)
            self.state = 106
            self.variable()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exprStmt(self):
            return self.getTypedRuleContext(CompiscriptParser.ExprStmtContext,0)


        def forStmt(self):
            return self.getTypedRuleContext(CompiscriptParser.ForStmtContext,0)


        def ifStmt(self):
            return self.getTypedRuleContext(CompiscriptParser.IfStmtContext,0)


        def printStmt(self):
            return self.getTypedRuleContext(CompiscriptParser.PrintStmtContext,0)


        def returnStmt(self):
            return self.getTypedRuleContext(CompiscriptParser.ReturnStmtContext,0)


        def whileStmt(self):
            return self.getTypedRuleContext(CompiscriptParser.WhileStmtContext,0)


        def block(self):
            return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = CompiscriptParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_statement)
        try:
            self.state = 115
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 9, 28, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45]:
                self.enterOuterAlt(localctx, 1)
                self.state = 108
                self.exprStmt()
                pass
            elif token in [8]:
                self.enterOuterAlt(localctx, 2)
                self.state = 109
                self.forStmt()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 3)
                self.state = 110
                self.ifStmt()
                pass
            elif token in [13]:
                self.enterOuterAlt(localctx, 4)
                self.state = 111
                self.printStmt()
                pass
            elif token in [14]:
                self.enterOuterAlt(localctx, 5)
                self.state = 112
                self.returnStmt()
                pass
            elif token in [15]:
                self.enterOuterAlt(localctx, 6)
                self.state = 113
                self.whileStmt()
                pass
            elif token in [3]:
                self.enterOuterAlt(localctx, 7)
                self.state = 114
                self.block()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_exprStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprStmt" ):
                listener.enterExprStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprStmt" ):
                listener.exitExprStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprStmt" ):
                return visitor.visitExprStmt(self)
            else:
                return visitor.visitChildren(self)




    def exprStmt(self):

        localctx = CompiscriptParser.ExprStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_exprStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.expression()
            self.state = 118
            self.match(CompiscriptParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self):
            return self.getTypedRuleContext(CompiscriptParser.StatementContext,0)


        def varDecl(self):
            return self.getTypedRuleContext(CompiscriptParser.VarDeclContext,0)


        def exprStmt(self):
            return self.getTypedRuleContext(CompiscriptParser.ExprStmtContext,0)


        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_forStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForStmt" ):
                listener.enterForStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForStmt" ):
                listener.exitForStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitForStmt" ):
                return visitor.visitForStmt(self)
            else:
                return visitor.visitChildren(self)




    def forStmt(self):

        localctx = CompiscriptParser.ForStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_forStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 120
            self.match(CompiscriptParser.T__7)
            self.state = 121
            self.match(CompiscriptParser.T__8)
            self.state = 125
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [6]:
                self.state = 122
                self.varDecl()
                pass
            elif token in [5, 9, 28, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45]:
                self.state = 123
                self.exprStmt()
                pass
            elif token in [7]:
                self.state = 124
                self.match(CompiscriptParser.T__6)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 128
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 70308883071520) != 0):
                self.state = 127
                self.expression()


            self.state = 130
            self.match(CompiscriptParser.T__6)
            self.state = 132
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 70308883071520) != 0):
                self.state = 131
                self.expression()


            self.state = 134
            self.match(CompiscriptParser.T__9)
            self.state = 135
            self.statement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.StatementContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.StatementContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_ifStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfStmt" ):
                listener.enterIfStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfStmt" ):
                listener.exitIfStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfStmt" ):
                return visitor.visitIfStmt(self)
            else:
                return visitor.visitChildren(self)




    def ifStmt(self):

        localctx = CompiscriptParser.IfStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_ifStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 137
            self.match(CompiscriptParser.T__10)
            self.state = 138
            self.match(CompiscriptParser.T__8)
            self.state = 139
            self.expression()
            self.state = 140
            self.match(CompiscriptParser.T__9)
            self.state = 141
            self.statement()
            self.state = 144
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.state = 142
                self.match(CompiscriptParser.T__11)
                self.state = 143
                self.statement()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrintStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_printStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrintStmt" ):
                listener.enterPrintStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrintStmt" ):
                listener.exitPrintStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrintStmt" ):
                return visitor.visitPrintStmt(self)
            else:
                return visitor.visitChildren(self)




    def printStmt(self):

        localctx = CompiscriptParser.PrintStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_printStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 146
            self.match(CompiscriptParser.T__12)
            self.state = 147
            self.expression()
            self.state = 148
            self.match(CompiscriptParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReturnStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_returnStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReturnStmt" ):
                listener.enterReturnStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReturnStmt" ):
                listener.exitReturnStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReturnStmt" ):
                return visitor.visitReturnStmt(self)
            else:
                return visitor.visitChildren(self)




    def returnStmt(self):

        localctx = CompiscriptParser.ReturnStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_returnStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self.match(CompiscriptParser.T__13)
            self.state = 152
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 70308883071520) != 0):
                self.state = 151
                self.expression()


            self.state = 154
            self.match(CompiscriptParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhileStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def statement(self):
            return self.getTypedRuleContext(CompiscriptParser.StatementContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_whileStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhileStmt" ):
                listener.enterWhileStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhileStmt" ):
                listener.exitWhileStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhileStmt" ):
                return visitor.visitWhileStmt(self)
            else:
                return visitor.visitChildren(self)




    def whileStmt(self):

        localctx = CompiscriptParser.WhileStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_whileStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 156
            self.match(CompiscriptParser.T__14)
            self.state = 157
            self.match(CompiscriptParser.T__8)
            self.state = 158
            self.expression()
            self.state = 159
            self.match(CompiscriptParser.T__9)
            self.state = 160
            self.statement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.DeclarationContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.DeclarationContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_block

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlock" ):
                listener.enterBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlock" ):
                listener.exitBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock" ):
                return visitor.visitBlock(self)
            else:
                return visitor.visitChildren(self)




    def block(self):

        localctx = CompiscriptParser.BlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 162
            self.match(CompiscriptParser.T__2)
            self.state = 166
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 70308883131242) != 0):
                self.state = 163
                self.declaration()
                self.state = 168
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 169
            self.match(CompiscriptParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunAnonContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def block(self):
            return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


        def parameters(self):
            return self.getTypedRuleContext(CompiscriptParser.ParametersContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_funAnon

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunAnon" ):
                listener.enterFunAnon(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunAnon" ):
                listener.exitFunAnon(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunAnon" ):
                return visitor.visitFunAnon(self)
            else:
                return visitor.visitChildren(self)




    def funAnon(self):

        localctx = CompiscriptParser.FunAnonContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_funAnon)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 171
            self.match(CompiscriptParser.T__4)
            self.state = 172
            self.match(CompiscriptParser.T__8)
            self.state = 174
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==45:
                self.state = 173
                self.parameters()


            self.state = 176
            self.match(CompiscriptParser.T__9)
            self.state = 177
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assignment(self):
            return self.getTypedRuleContext(CompiscriptParser.AssignmentContext,0)


        def funAnon(self):
            return self.getTypedRuleContext(CompiscriptParser.FunAnonContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression" ):
                return visitor.visitExpression(self)
            else:
                return visitor.visitChildren(self)




    def expression(self):

        localctx = CompiscriptParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_expression)
        try:
            self.state = 181
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 179
                self.assignment()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 180
                self.funAnon()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(CompiscriptParser.IDENTIFIER, 0)

        def assignment(self):
            return self.getTypedRuleContext(CompiscriptParser.AssignmentContext,0)


        def call(self):
            return self.getTypedRuleContext(CompiscriptParser.CallContext,0)


        def logic_or(self):
            return self.getTypedRuleContext(CompiscriptParser.Logic_orContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignment" ):
                listener.enterAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignment" ):
                listener.exitAssignment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignment" ):
                return visitor.visitAssignment(self)
            else:
                return visitor.visitChildren(self)




    def assignment(self):

        localctx = CompiscriptParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_assignment)
        try:
            self.state = 192
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 186
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
                if la_ == 1:
                    self.state = 183
                    self.call()
                    self.state = 184
                    self.match(CompiscriptParser.T__15)


                self.state = 188
                self.match(CompiscriptParser.IDENTIFIER)
                self.state = 189
                self.match(CompiscriptParser.T__16)
                self.state = 190
                self.assignment()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 191
                self.logic_or()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Logic_orContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def logic_and(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.Logic_andContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.Logic_andContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_logic_or

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogic_or" ):
                listener.enterLogic_or(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogic_or" ):
                listener.exitLogic_or(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogic_or" ):
                return visitor.visitLogic_or(self)
            else:
                return visitor.visitChildren(self)




    def logic_or(self):

        localctx = CompiscriptParser.Logic_orContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_logic_or)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 194
            self.logic_and()
            self.state = 199
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==18 or _la==19:
                self.state = 195
                _la = self._input.LA(1)
                if not(_la==18 or _la==19):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 196
                self.logic_and()
                self.state = 201
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Logic_andContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def equality(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.EqualityContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.EqualityContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_logic_and

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogic_and" ):
                listener.enterLogic_and(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogic_and" ):
                listener.exitLogic_and(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogic_and" ):
                return visitor.visitLogic_and(self)
            else:
                return visitor.visitChildren(self)




    def logic_and(self):

        localctx = CompiscriptParser.Logic_andContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_logic_and)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self.equality()
            self.state = 207
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==20 or _la==21:
                self.state = 203
                _la = self._input.LA(1)
                if not(_la==20 or _la==21):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 204
                self.equality()
                self.state = 209
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EqualityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comparison(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ComparisonContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ComparisonContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_equality

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEquality" ):
                listener.enterEquality(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEquality" ):
                listener.exitEquality(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEquality" ):
                return visitor.visitEquality(self)
            else:
                return visitor.visitChildren(self)




    def equality(self):

        localctx = CompiscriptParser.EqualityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_equality)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 210
            self.comparison()
            self.state = 215
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==22 or _la==23:
                self.state = 211
                _la = self._input.LA(1)
                if not(_la==22 or _la==23):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 212
                self.comparison()
                self.state = 217
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.TermContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.TermContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_comparison

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparison" ):
                listener.enterComparison(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparison" ):
                listener.exitComparison(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparison" ):
                return visitor.visitComparison(self)
            else:
                return visitor.visitChildren(self)




    def comparison(self):

        localctx = CompiscriptParser.ComparisonContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_comparison)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 218
            self.term()
            self.state = 223
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 251658240) != 0):
                self.state = 219
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 251658240) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 220
                self.term()
                self.state = 225
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def factor(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.FactorContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.FactorContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerm" ):
                listener.enterTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerm" ):
                listener.exitTerm(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTerm" ):
                return visitor.visitTerm(self)
            else:
                return visitor.visitChildren(self)




    def term(self):

        localctx = CompiscriptParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_term)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 226
            self.factor()
            self.state = 231
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==28 or _la==29:
                self.state = 227
                _la = self._input.LA(1)
                if not(_la==28 or _la==29):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 228
                self.factor()
                self.state = 233
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unary(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.UnaryContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.UnaryContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor" ):
                listener.enterFactor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor" ):
                listener.exitFactor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor" ):
                return visitor.visitFactor(self)
            else:
                return visitor.visitChildren(self)




    def factor(self):

        localctx = CompiscriptParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_factor)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 234
            self.unary()
            self.state = 239
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 7516192768) != 0):
                self.state = 235
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 7516192768) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 236
                self.unary()
                self.state = 241
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArrayContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_array

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArray" ):
                listener.enterArray(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArray" ):
                listener.exitArray(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArray" ):
                return visitor.visitArray(self)
            else:
                return visitor.visitChildren(self)




    def array(self):

        localctx = CompiscriptParser.ArrayContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_array)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 242
            self.match(CompiscriptParser.T__32)
            self.state = 251
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 70308883071520) != 0):
                self.state = 243
                self.expression()
                self.state = 248
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==34:
                    self.state = 244
                    self.match(CompiscriptParser.T__33)
                    self.state = 245
                    self.expression()
                    self.state = 250
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 253
            self.match(CompiscriptParser.T__34)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstantiationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(CompiscriptParser.IDENTIFIER, 0)

        def arguments(self):
            return self.getTypedRuleContext(CompiscriptParser.ArgumentsContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_instantiation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstantiation" ):
                listener.enterInstantiation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstantiation" ):
                listener.exitInstantiation(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstantiation" ):
                return visitor.visitInstantiation(self)
            else:
                return visitor.visitChildren(self)




    def instantiation(self):

        localctx = CompiscriptParser.InstantiationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_instantiation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 255
            self.match(CompiscriptParser.T__35)
            self.state = 256
            self.match(CompiscriptParser.IDENTIFIER)
            self.state = 257
            self.match(CompiscriptParser.T__8)
            self.state = 259
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 70308883071520) != 0):
                self.state = 258
                self.arguments()


            self.state = 261
            self.match(CompiscriptParser.T__9)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unary(self):
            return self.getTypedRuleContext(CompiscriptParser.UnaryContext,0)


        def call(self):
            return self.getTypedRuleContext(CompiscriptParser.CallContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_unary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnary" ):
                listener.enterUnary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnary" ):
                listener.exitUnary(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnary" ):
                return visitor.visitUnary(self)
            else:
                return visitor.visitChildren(self)




    def unary(self):

        localctx = CompiscriptParser.UnaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_unary)
        self._la = 0 # Token type
        try:
            self.state = 266
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28, 37]:
                self.enterOuterAlt(localctx, 1)
                self.state = 263
                _la = self._input.LA(1)
                if not(_la==28 or _la==37):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 264
                self.unary()
                pass
            elif token in [5, 9, 33, 36, 38, 39, 40, 41, 42, 43, 44, 45]:
                self.enterOuterAlt(localctx, 2)
                self.state = 265
                self.call()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primary(self):
            return self.getTypedRuleContext(CompiscriptParser.PrimaryContext,0)


        def callSuffix(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.CallSuffixContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.CallSuffixContext,i)


        def funAnon(self):
            return self.getTypedRuleContext(CompiscriptParser.FunAnonContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_call

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCall" ):
                listener.enterCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCall" ):
                listener.exitCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCall" ):
                return visitor.visitCall(self)
            else:
                return visitor.visitChildren(self)




    def call(self):

        localctx = CompiscriptParser.CallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_call)
        try:
            self.state = 276
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [9, 33, 36, 38, 39, 40, 41, 42, 43, 44, 45]:
                self.enterOuterAlt(localctx, 1)
                self.state = 268
                self.primary()
                self.state = 272
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,25,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 269
                        self.callSuffix() 
                    self.state = 274
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,25,self._ctx)

                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 275
                self.funAnon()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CallSuffixContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def arguments(self):
            return self.getTypedRuleContext(CompiscriptParser.ArgumentsContext,0)


        def IDENTIFIER(self):
            return self.getToken(CompiscriptParser.IDENTIFIER, 0)

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_callSuffix

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCallSuffix" ):
                listener.enterCallSuffix(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCallSuffix" ):
                listener.exitCallSuffix(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCallSuffix" ):
                return visitor.visitCallSuffix(self)
            else:
                return visitor.visitChildren(self)




    def callSuffix(self):

        localctx = CompiscriptParser.CallSuffixContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_callSuffix)
        self._la = 0 # Token type
        try:
            self.state = 291
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,28,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 278
                self.match(CompiscriptParser.T__8)
                self.state = 279
                self.match(CompiscriptParser.T__9)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 280
                self.match(CompiscriptParser.T__8)
                self.state = 282
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 70308883071520) != 0):
                    self.state = 281
                    self.arguments()


                self.state = 284
                self.match(CompiscriptParser.T__9)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 285
                self.match(CompiscriptParser.T__15)
                self.state = 286
                self.match(CompiscriptParser.IDENTIFIER)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 287
                self.match(CompiscriptParser.T__32)
                self.state = 288
                self.expression()
                self.state = 289
                self.match(CompiscriptParser.T__34)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SuperCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(CompiscriptParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return CompiscriptParser.RULE_superCall

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSuperCall" ):
                listener.enterSuperCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSuperCall" ):
                listener.exitSuperCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSuperCall" ):
                return visitor.visitSuperCall(self)
            else:
                return visitor.visitChildren(self)




    def superCall(self):

        localctx = CompiscriptParser.SuperCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_superCall)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 293
            self.match(CompiscriptParser.T__37)
            self.state = 294
            self.match(CompiscriptParser.T__15)
            self.state = 295
            self.match(CompiscriptParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self):
            return self.getToken(CompiscriptParser.NUMBER, 0)

        def STRING(self):
            return self.getToken(CompiscriptParser.STRING, 0)

        def IDENTIFIER(self):
            return self.getToken(CompiscriptParser.IDENTIFIER, 0)

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def superCall(self):
            return self.getTypedRuleContext(CompiscriptParser.SuperCallContext,0)


        def array(self):
            return self.getTypedRuleContext(CompiscriptParser.ArrayContext,0)


        def instantiation(self):
            return self.getTypedRuleContext(CompiscriptParser.InstantiationContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_primary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimary" ):
                listener.enterPrimary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimary" ):
                listener.exitPrimary(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrimary" ):
                return visitor.visitPrimary(self)
            else:
                return visitor.visitChildren(self)




    def primary(self):

        localctx = CompiscriptParser.PrimaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_primary)
        try:
            self.state = 311
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [39]:
                self.enterOuterAlt(localctx, 1)
                self.state = 297
                self.match(CompiscriptParser.T__38)
                pass
            elif token in [40]:
                self.enterOuterAlt(localctx, 2)
                self.state = 298
                self.match(CompiscriptParser.T__39)
                pass
            elif token in [41]:
                self.enterOuterAlt(localctx, 3)
                self.state = 299
                self.match(CompiscriptParser.T__40)
                pass
            elif token in [42]:
                self.enterOuterAlt(localctx, 4)
                self.state = 300
                self.match(CompiscriptParser.T__41)
                pass
            elif token in [43]:
                self.enterOuterAlt(localctx, 5)
                self.state = 301
                self.match(CompiscriptParser.NUMBER)
                pass
            elif token in [44]:
                self.enterOuterAlt(localctx, 6)
                self.state = 302
                self.match(CompiscriptParser.STRING)
                pass
            elif token in [45]:
                self.enterOuterAlt(localctx, 7)
                self.state = 303
                self.match(CompiscriptParser.IDENTIFIER)
                pass
            elif token in [9]:
                self.enterOuterAlt(localctx, 8)
                self.state = 304
                self.match(CompiscriptParser.T__8)
                self.state = 305
                self.expression()
                self.state = 306
                self.match(CompiscriptParser.T__9)
                pass
            elif token in [38]:
                self.enterOuterAlt(localctx, 9)
                self.state = 308
                self.superCall()
                pass
            elif token in [33]:
                self.enterOuterAlt(localctx, 10)
                self.state = 309
                self.array()
                pass
            elif token in [36]:
                self.enterOuterAlt(localctx, 11)
                self.state = 310
                self.instantiation()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(CompiscriptParser.IDENTIFIER, 0)

        def block(self):
            return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


        def parameters(self):
            return self.getTypedRuleContext(CompiscriptParser.ParametersContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction" ):
                listener.enterFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction" ):
                listener.exitFunction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction" ):
                return visitor.visitFunction(self)
            else:
                return visitor.visitChildren(self)




    def function(self):

        localctx = CompiscriptParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 313
            self.match(CompiscriptParser.IDENTIFIER)
            self.state = 314
            self.match(CompiscriptParser.T__8)
            self.state = 316
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==45:
                self.state = 315
                self.parameters()


            self.state = 318
            self.match(CompiscriptParser.T__9)
            self.state = 319
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(CompiscriptParser.IDENTIFIER, 0)

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable" ):
                listener.enterVariable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable" ):
                listener.exitVariable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariable" ):
                return visitor.visitVariable(self)
            else:
                return visitor.visitChildren(self)




    def variable(self):

        localctx = CompiscriptParser.VariableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_variable)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 321
            self.match(CompiscriptParser.IDENTIFIER)
            self.state = 324
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17:
                self.state = 322
                self.match(CompiscriptParser.T__16)
                self.state = 323
                self.expression()


            self.state = 326
            self.match(CompiscriptParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self, i:int=None):
            if i is None:
                return self.getTokens(CompiscriptParser.IDENTIFIER)
            else:
                return self.getToken(CompiscriptParser.IDENTIFIER, i)

        def getRuleIndex(self):
            return CompiscriptParser.RULE_parameters

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameters" ):
                listener.enterParameters(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameters" ):
                listener.exitParameters(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameters" ):
                return visitor.visitParameters(self)
            else:
                return visitor.visitChildren(self)




    def parameters(self):

        localctx = CompiscriptParser.ParametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 328
            self.match(CompiscriptParser.IDENTIFIER)
            self.state = 333
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==34:
                self.state = 329
                self.match(CompiscriptParser.T__33)
                self.state = 330
                self.match(CompiscriptParser.IDENTIFIER)
                self.state = 335
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_arguments

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArguments" ):
                listener.enterArguments(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArguments" ):
                listener.exitArguments(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArguments" ):
                return visitor.visitArguments(self)
            else:
                return visitor.visitChildren(self)




    def arguments(self):

        localctx = CompiscriptParser.ArgumentsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_arguments)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 336
            self.expression()
            self.state = 341
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==34:
                self.state = 337
                self.match(CompiscriptParser.T__33)
                self.state = 338
                self.expression()
                self.state = 343
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





