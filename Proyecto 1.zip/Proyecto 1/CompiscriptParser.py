# Generated from Compiscript.g4 by ANTLR 4.13.1
# encoding: utf-8
from typing import TextIO
from antlr4 import *
import sys

def serializedATN():
	return [
		4,1,45,323,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
		6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
		2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
		7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
		2,27,7,27,2,28,7,28,2,29,7,29,1,0,5,0,62,8,0,10,0,12,0,65,9,0,1,
		0,1,0,1,1,1,1,1,1,1,1,3,1,73,8,1,1,2,1,2,1,2,1,2,3,2,79,8,2,1,2,
		1,2,5,2,83,8,2,10,2,12,2,86,9,2,1,2,1,2,1,3,1,3,1,3,1,4,1,4,1,4,
		1,4,3,4,97,8,4,1,4,1,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,108,8,5,1,
		6,1,6,1,6,1,7,1,7,1,7,1,7,1,7,3,7,118,8,7,1,7,3,7,121,8,7,1,7,1,
		7,3,7,125,8,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,1,8,3,8,137,8,
		8,1,9,1,9,1,9,1,9,1,10,1,10,3,10,145,8,10,1,10,1,10,1,11,1,11,1,
		11,1,11,1,11,1,11,1,12,1,12,5,12,157,8,12,10,12,12,12,160,9,12,1,
		12,1,12,1,13,1,13,1,13,3,13,167,8,13,1,13,1,13,1,13,1,14,1,14,3,
		14,174,8,14,1,15,1,15,1,15,3,15,179,8,15,1,15,1,15,1,15,1,15,3,15,
		185,8,15,1,16,1,16,1,16,5,16,190,8,16,10,16,12,16,193,9,16,1,17,
		1,17,1,17,5,17,198,8,17,10,17,12,17,201,9,17,1,18,1,18,1,18,5,18,
		206,8,18,10,18,12,18,209,9,18,1,19,1,19,1,19,5,19,214,8,19,10,19,
		12,19,217,9,19,1,20,1,20,1,20,5,20,222,8,20,10,20,12,20,225,9,20,
		1,21,1,21,1,21,5,21,230,8,21,10,21,12,21,233,9,21,1,22,1,22,1,22,
		1,22,5,22,239,8,22,10,22,12,22,242,9,22,3,22,244,8,22,1,22,1,22,
		1,23,1,23,1,23,1,23,3,23,252,8,23,1,23,1,23,1,24,1,24,1,24,3,24,
		259,8,24,1,25,1,25,1,25,3,25,264,8,25,1,25,1,25,1,25,1,25,1,25,1,
		25,1,25,5,25,273,8,25,10,25,12,25,276,9,25,1,25,3,25,279,8,25,1,
		26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,
		26,1,26,1,26,3,26,297,8,26,1,27,1,27,1,27,3,27,302,8,27,1,27,1,27,
		1,27,1,28,1,28,1,28,5,28,310,8,28,10,28,12,28,313,9,28,1,29,1,29,
		1,29,5,29,318,8,29,10,29,12,29,321,9,29,1,29,0,0,30,0,2,4,6,8,10,
		12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,
		56,58,0,5,1,0,20,21,1,0,22,25,1,0,26,27,1,0,28,30,2,0,26,26,35,35,
		344,0,63,1,0,0,0,2,72,1,0,0,0,4,74,1,0,0,0,6,89,1,0,0,0,8,92,1,0,
		0,0,10,107,1,0,0,0,12,109,1,0,0,0,14,112,1,0,0,0,16,129,1,0,0,0,
		18,138,1,0,0,0,20,142,1,0,0,0,22,148,1,0,0,0,24,154,1,0,0,0,26,163,
		1,0,0,0,28,173,1,0,0,0,30,184,1,0,0,0,32,186,1,0,0,0,34,194,1,0,
		0,0,36,202,1,0,0,0,38,210,1,0,0,0,40,218,1,0,0,0,42,226,1,0,0,0,
		44,234,1,0,0,0,46,247,1,0,0,0,48,258,1,0,0,0,50,278,1,0,0,0,52,296,
		1,0,0,0,54,298,1,0,0,0,56,306,1,0,0,0,58,314,1,0,0,0,60,62,3,2,1,
		0,61,60,1,0,0,0,62,65,1,0,0,0,63,61,1,0,0,0,63,64,1,0,0,0,64,66,
		1,0,0,0,65,63,1,0,0,0,66,67,5,0,0,1,67,1,1,0,0,0,68,73,3,4,2,0,69,
		73,3,6,3,0,70,73,3,8,4,0,71,73,3,10,5,0,72,68,1,0,0,0,72,69,1,0,
		0,0,72,70,1,0,0,0,72,71,1,0,0,0,73,3,1,0,0,0,74,75,5,1,0,0,75,78,
		5,43,0,0,76,77,5,2,0,0,77,79,5,43,0,0,78,76,1,0,0,0,78,79,1,0,0,
		0,79,80,1,0,0,0,80,84,5,3,0,0,81,83,3,54,27,0,82,81,1,0,0,0,83,86,
		1,0,0,0,84,82,1,0,0,0,84,85,1,0,0,0,85,87,1,0,0,0,86,84,1,0,0,0,
		87,88,5,4,0,0,88,5,1,0,0,0,89,90,5,5,0,0,90,91,3,54,27,0,91,7,1,
		0,0,0,92,93,5,6,0,0,93,96,5,43,0,0,94,95,5,7,0,0,95,97,3,28,14,0,
		96,94,1,0,0,0,96,97,1,0,0,0,97,98,1,0,0,0,98,99,5,8,0,0,99,9,1,0,
		0,0,100,108,3,12,6,0,101,108,3,14,7,0,102,108,3,16,8,0,103,108,3,
		18,9,0,104,108,3,20,10,0,105,108,3,22,11,0,106,108,3,24,12,0,107,
		100,1,0,0,0,107,101,1,0,0,0,107,102,1,0,0,0,107,103,1,0,0,0,107,
		104,1,0,0,0,107,105,1,0,0,0,107,106,1,0,0,0,108,11,1,0,0,0,109,110,
		3,28,14,0,110,111,5,8,0,0,111,13,1,0,0,0,112,113,5,9,0,0,113,117,
		5,10,0,0,114,118,3,8,4,0,115,118,3,12,6,0,116,118,5,8,0,0,117,114,
		1,0,0,0,117,115,1,0,0,0,117,116,1,0,0,0,118,120,1,0,0,0,119,121,
		3,28,14,0,120,119,1,0,0,0,120,121,1,0,0,0,121,122,1,0,0,0,122,124,
		5,8,0,0,123,125,3,28,14,0,124,123,1,0,0,0,124,125,1,0,0,0,125,126,
		1,0,0,0,126,127,5,11,0,0,127,128,3,10,5,0,128,15,1,0,0,0,129,130,
		5,12,0,0,130,131,5,10,0,0,131,132,3,28,14,0,132,133,5,11,0,0,133,
		136,3,10,5,0,134,135,5,13,0,0,135,137,3,10,5,0,136,134,1,0,0,0,136,
		137,1,0,0,0,137,17,1,0,0,0,138,139,5,14,0,0,139,140,3,28,14,0,140,
		141,5,8,0,0,141,19,1,0,0,0,142,144,5,15,0,0,143,145,3,28,14,0,144,
		143,1,0,0,0,144,145,1,0,0,0,145,146,1,0,0,0,146,147,5,8,0,0,147,
		21,1,0,0,0,148,149,5,16,0,0,149,150,5,10,0,0,150,151,3,28,14,0,151,
		152,5,11,0,0,152,153,3,10,5,0,153,23,1,0,0,0,154,158,5,3,0,0,155,
		157,3,2,1,0,156,155,1,0,0,0,157,160,1,0,0,0,158,156,1,0,0,0,158,
		159,1,0,0,0,159,161,1,0,0,0,160,158,1,0,0,0,161,162,5,4,0,0,162,
		25,1,0,0,0,163,164,5,5,0,0,164,166,5,10,0,0,165,167,3,56,28,0,166,
		165,1,0,0,0,166,167,1,0,0,0,167,168,1,0,0,0,168,169,5,11,0,0,169,
		170,3,24,12,0,170,27,1,0,0,0,171,174,3,30,15,0,172,174,3,26,13,0,
		173,171,1,0,0,0,173,172,1,0,0,0,174,29,1,0,0,0,175,176,3,50,25,0,
		176,177,5,17,0,0,177,179,1,0,0,0,178,175,1,0,0,0,178,179,1,0,0,0,
		179,180,1,0,0,0,180,181,5,43,0,0,181,182,5,7,0,0,182,185,3,30,15,
		0,183,185,3,32,16,0,184,178,1,0,0,0,184,183,1,0,0,0,185,31,1,0,0,
		0,186,191,3,34,17,0,187,188,5,18,0,0,188,190,3,34,17,0,189,187,1,
		0,0,0,190,193,1,0,0,0,191,189,1,0,0,0,191,192,1,0,0,0,192,33,1,0,
		0,0,193,191,1,0,0,0,194,199,3,36,18,0,195,196,5,19,0,0,196,198,3,
		36,18,0,197,195,1,0,0,0,198,201,1,0,0,0,199,197,1,0,0,0,199,200,
		1,0,0,0,200,35,1,0,0,0,201,199,1,0,0,0,202,207,3,38,19,0,203,204,
		7,0,0,0,204,206,3,38,19,0,205,203,1,0,0,0,206,209,1,0,0,0,207,205,
		1,0,0,0,207,208,1,0,0,0,208,37,1,0,0,0,209,207,1,0,0,0,210,215,3,
		40,20,0,211,212,7,1,0,0,212,214,3,40,20,0,213,211,1,0,0,0,214,217,
		1,0,0,0,215,213,1,0,0,0,215,216,1,0,0,0,216,39,1,0,0,0,217,215,1,
		0,0,0,218,223,3,42,21,0,219,220,7,2,0,0,220,222,3,42,21,0,221,219,
		1,0,0,0,222,225,1,0,0,0,223,221,1,0,0,0,223,224,1,0,0,0,224,41,1,
		0,0,0,225,223,1,0,0,0,226,231,3,48,24,0,227,228,7,3,0,0,228,230,
		3,48,24,0,229,227,1,0,0,0,230,233,1,0,0,0,231,229,1,0,0,0,231,232,
		1,0,0,0,232,43,1,0,0,0,233,231,1,0,0,0,234,243,5,31,0,0,235,240,
		3,28,14,0,236,237,5,32,0,0,237,239,3,28,14,0,238,236,1,0,0,0,239,
		242,1,0,0,0,240,238,1,0,0,0,240,241,1,0,0,0,241,244,1,0,0,0,242,
		240,1,0,0,0,243,235,1,0,0,0,243,244,1,0,0,0,244,245,1,0,0,0,245,
		246,5,33,0,0,246,45,1,0,0,0,247,248,5,34,0,0,248,249,5,43,0,0,249,
		251,5,10,0,0,250,252,3,58,29,0,251,250,1,0,0,0,251,252,1,0,0,0,252,
		253,1,0,0,0,253,254,5,11,0,0,254,47,1,0,0,0,255,256,7,4,0,0,256,
		259,3,48,24,0,257,259,3,50,25,0,258,255,1,0,0,0,258,257,1,0,0,0,
		259,49,1,0,0,0,260,274,3,52,26,0,261,263,5,10,0,0,262,264,3,58,29,
		0,263,262,1,0,0,0,263,264,1,0,0,0,264,265,1,0,0,0,265,273,5,11,0,
		0,266,267,5,17,0,0,267,273,5,43,0,0,268,269,5,31,0,0,269,270,3,28,
		14,0,270,271,5,33,0,0,271,273,1,0,0,0,272,261,1,0,0,0,272,266,1,
		0,0,0,272,268,1,0,0,0,273,276,1,0,0,0,274,272,1,0,0,0,274,275,1,
		0,0,0,275,279,1,0,0,0,276,274,1,0,0,0,277,279,3,26,13,0,278,260,
		1,0,0,0,278,277,1,0,0,0,279,51,1,0,0,0,280,297,5,36,0,0,281,297,
		5,37,0,0,282,297,5,38,0,0,283,297,5,39,0,0,284,297,5,41,0,0,285,
		297,5,42,0,0,286,297,5,43,0,0,287,288,5,10,0,0,288,289,3,28,14,0,
		289,290,5,11,0,0,290,297,1,0,0,0,291,292,5,40,0,0,292,293,5,17,0,
		0,293,297,5,43,0,0,294,297,3,44,22,0,295,297,3,46,23,0,296,280,1,
		0,0,0,296,281,1,0,0,0,296,282,1,0,0,0,296,283,1,0,0,0,296,284,1,
		0,0,0,296,285,1,0,0,0,296,286,1,0,0,0,296,287,1,0,0,0,296,291,1,
		0,0,0,296,294,1,0,0,0,296,295,1,0,0,0,297,53,1,0,0,0,298,299,5,43,
		0,0,299,301,5,10,0,0,300,302,3,56,28,0,301,300,1,0,0,0,301,302,1,
		0,0,0,302,303,1,0,0,0,303,304,5,11,0,0,304,305,3,24,12,0,305,55,
		1,0,0,0,306,311,5,43,0,0,307,308,5,32,0,0,308,310,5,43,0,0,309,307,
		1,0,0,0,310,313,1,0,0,0,311,309,1,0,0,0,311,312,1,0,0,0,312,57,1,
		0,0,0,313,311,1,0,0,0,314,319,3,28,14,0,315,316,5,32,0,0,316,318,
		3,28,14,0,317,315,1,0,0,0,318,321,1,0,0,0,319,317,1,0,0,0,319,320,
		1,0,0,0,320,59,1,0,0,0,321,319,1,0,0,0,34,63,72,78,84,96,107,117,
		120,124,136,144,158,166,173,178,184,191,199,207,215,223,231,240,
		243,251,258,263,272,274,278,296,301,311,319
	]

class CompiscriptParser ( Parser ):

	grammarFileName = "Compiscript.g4"

	atn = ATNDeserializer().deserialize(serializedATN())

	decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

	sharedContextCache = PredictionContextCache()

	literalNames = [ "<INVALID>", "'class'", "'extends'", "'{'", "'}'", 
					"'fun'", "'var'", "'='", "';'", "'for'", "'('", "')'", 
					"'if'", "'else'", "'print'", "'return'", "'while'", 
					"'.'", "'or'", "'and'", "'!='", "'=='", "'>'", "'>='", 
					"'<'", "'<='", "'-'", "'+'", "'/'", "'*'", "'%'", "'['", 
					"','", "']'", "'new'", "'!'", "'true'", "'false'", 
					"'nil'", "'this'", "'super'" ]

	symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
					"<INVALID>", "NUMBER", "STRING", "IDENTIFIER", "WS", 
					"ONE_LINE_COMMENT" ]

	RULE_program = 0
	RULE_declaration = 1
	RULE_classDecl = 2
	RULE_funDecl = 3
	RULE_varDecl = 4
	RULE_statement = 5
	RULE_exprStmt = 6
	RULE_forStmt = 7
	RULE_ifStmt = 8
	RULE_printStmt = 9
	RULE_returnStmt = 10
	RULE_whileStmt = 11
	RULE_block = 12
	RULE_funAnon = 13
	RULE_expression = 14
	RULE_assignment = 15
	RULE_logic_or = 16
	RULE_logic_and = 17
	RULE_equality = 18
	RULE_comparison = 19
	RULE_term = 20
	RULE_factor = 21
	RULE_array = 22
	RULE_instantiation = 23
	RULE_unary = 24
	RULE_call = 25
	RULE_primary = 26
	RULE_function = 27
	RULE_parameters = 28
	RULE_arguments = 29

	ruleNames =  [ "program", "declaration", "classDecl", "funDecl", "varDecl", 
				"statement", "exprStmt", "forStmt", "ifStmt", "printStmt", 
				"returnStmt", "whileStmt", "block", "funAnon", "expression", 
				"assignment", "logic_or", "logic_and", "equality", "comparison", 
				"term", "factor", "array", "instantiation", "unary", 
				"call", "primary", "function", "parameters", "arguments" ]

	EOF = Token.EOF
	T__0=1
	T__1=2
	T__2=3
	T__3=4
	T__4=5
	T__5=6
	T__6=7
	T__7=8
	T__8=9
	T__9=10
	T__10=11
	T__11=12
	T__12=13
	T__13=14
	T__14=15
	T__15=16
	T__16=17
	T__17=18
	T__18=19
	T__19=20
	T__20=21
	T__21=22
	T__22=23
	T__23=24
	T__24=25
	T__25=26
	T__26=27
	T__27=28
	T__28=29
	T__29=30
	T__30=31
	T__31=32
	T__32=33
	T__33=34
	T__34=35
	T__35=36
	T__36=37
	T__37=38
	T__38=39
	T__39=40
	NUMBER=41
	STRING=42
	IDENTIFIER=43
	WS=44
	ONE_LINE_COMMENT=45

	def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
		super().__init__(input, output)
		self.checkVersion("4.13.1")
		self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
		self._predicates = None




	class ProgramContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def EOF(self):
			return self.getToken(CompiscriptParser.EOF, 0)

		def declaration(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.DeclarationContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.DeclarationContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_program

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterProgram" ):
				listener.enterProgram(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitProgram" ):
				listener.exitProgram(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitProgram" ):
				return visitor.visitProgram(self)
			else:
				return visitor.visitChildren(self)




	def program(self):

		localctx = CompiscriptParser.ProgramContext(self, self._ctx, self.state)
		self.enterRule(localctx, 0, self.RULE_program)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 63
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while (((_la) & ~0x3f) == 0 and ((1 << _la) & 17577220888170) != 0):
				self.state = 60
				self.declaration()
				self.state = 65
				self._errHandler.sync(self)
				_la = self._input.LA(1)

			self.state = 66
			self.match(CompiscriptParser.EOF)
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class DeclarationContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def classDecl(self):
			return self.getTypedRuleContext(CompiscriptParser.ClassDeclContext,0)


		def funDecl(self):
			return self.getTypedRuleContext(CompiscriptParser.FunDeclContext,0)


		def varDecl(self):
			return self.getTypedRuleContext(CompiscriptParser.VarDeclContext,0)


		def statement(self):
			return self.getTypedRuleContext(CompiscriptParser.StatementContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_declaration

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterDeclaration" ):
				listener.enterDeclaration(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitDeclaration" ):
				listener.exitDeclaration(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitDeclaration" ):
				return visitor.visitDeclaration(self)
			else:
				return visitor.visitChildren(self)




	def declaration(self):

		localctx = CompiscriptParser.DeclarationContext(self, self._ctx, self.state)
		self.enterRule(localctx, 2, self.RULE_declaration)
		try:
			self.state = 72
			self._errHandler.sync(self)
			la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
			if la_ == 1:
				self.enterOuterAlt(localctx, 1)
				self.state = 68
				self.classDecl()
				pass

			elif la_ == 2:
				self.enterOuterAlt(localctx, 2)
				self.state = 69
				self.funDecl()
				pass

			elif la_ == 3:
				self.enterOuterAlt(localctx, 3)
				self.state = 70
				self.varDecl()
				pass

			elif la_ == 4:
				self.enterOuterAlt(localctx, 4)
				self.state = 71
				self.statement()
				pass


		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class ClassDeclContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def IDENTIFIER(self, i:int=None):
			if i is None:
				return self.getTokens(CompiscriptParser.IDENTIFIER)
			else:
				return self.getToken(CompiscriptParser.IDENTIFIER, i)

		def function(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.FunctionContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.FunctionContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_classDecl

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterClassDecl" ):
				listener.enterClassDecl(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitClassDecl" ):
				listener.exitClassDecl(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitClassDecl" ):
				return visitor.visitClassDecl(self)
			else:
				return visitor.visitChildren(self)




	def classDecl(self):

		localctx = CompiscriptParser.ClassDeclContext(self, self._ctx, self.state)
		self.enterRule(localctx, 4, self.RULE_classDecl)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 74
			self.match(CompiscriptParser.T__0)
			self.state = 75
			self.match(CompiscriptParser.IDENTIFIER)
			self.state = 78
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			if _la==2:
				self.state = 76
				self.match(CompiscriptParser.T__1)
				self.state = 77
				self.match(CompiscriptParser.IDENTIFIER)


			self.state = 80
			self.match(CompiscriptParser.T__2)
			self.state = 84
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while _la==43:
				self.state = 81
				self.function()
				self.state = 86
				self._errHandler.sync(self)
				_la = self._input.LA(1)

			self.state = 87
			self.match(CompiscriptParser.T__3)
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class FunDeclContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def function(self):
			return self.getTypedRuleContext(CompiscriptParser.FunctionContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_funDecl

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterFunDecl" ):
				listener.enterFunDecl(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitFunDecl" ):
				listener.exitFunDecl(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitFunDecl" ):
				return visitor.visitFunDecl(self)
			else:
				return visitor.visitChildren(self)




	def funDecl(self):

		localctx = CompiscriptParser.FunDeclContext(self, self._ctx, self.state)
		self.enterRule(localctx, 6, self.RULE_funDecl)
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 89
			self.match(CompiscriptParser.T__4)
			self.state = 90
			self.function()
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class VarDeclContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def IDENTIFIER(self):
			return self.getToken(CompiscriptParser.IDENTIFIER, 0)

		def expression(self):
			return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_varDecl

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterVarDecl" ):
				listener.enterVarDecl(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitVarDecl" ):
				listener.exitVarDecl(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitVarDecl" ):
				return visitor.visitVarDecl(self)
			else:
				return visitor.visitChildren(self)




	def varDecl(self):

		localctx = CompiscriptParser.VarDeclContext(self, self._ctx, self.state)
		self.enterRule(localctx, 8, self.RULE_varDecl)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 92
			self.match(CompiscriptParser.T__5)
			self.state = 93
			self.match(CompiscriptParser.IDENTIFIER)
			self.state = 96
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			if _la==7:
				self.state = 94
				self.match(CompiscriptParser.T__6)
				self.state = 95
				self.expression()


			self.state = 98
			self.match(CompiscriptParser.T__7)
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class StatementContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def exprStmt(self):
			return self.getTypedRuleContext(CompiscriptParser.ExprStmtContext,0)


		def forStmt(self):
			return self.getTypedRuleContext(CompiscriptParser.ForStmtContext,0)


		def ifStmt(self):
			return self.getTypedRuleContext(CompiscriptParser.IfStmtContext,0)


		def printStmt(self):
			return self.getTypedRuleContext(CompiscriptParser.PrintStmtContext,0)


		def returnStmt(self):
			return self.getTypedRuleContext(CompiscriptParser.ReturnStmtContext,0)


		def whileStmt(self):
			return self.getTypedRuleContext(CompiscriptParser.WhileStmtContext,0)


		def block(self):
			return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_statement

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterStatement" ):
				listener.enterStatement(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitStatement" ):
				listener.exitStatement(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitStatement" ):
				return visitor.visitStatement(self)
			else:
				return visitor.visitChildren(self)




	def statement(self):

		localctx = CompiscriptParser.StatementContext(self, self._ctx, self.state)
		self.enterRule(localctx, 10, self.RULE_statement)
		try:
			self.state = 107
			self._errHandler.sync(self)
			token = self._input.LA(1)
			if token in [5, 10, 26, 31, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43]:
				self.enterOuterAlt(localctx, 1)
				self.state = 100
				self.exprStmt()
				pass
			elif token in [9]:
				self.enterOuterAlt(localctx, 2)
				self.state = 101
				self.forStmt()
				pass
			elif token in [12]:
				self.enterOuterAlt(localctx, 3)
				self.state = 102
				self.ifStmt()
				pass
			elif token in [14]:
				self.enterOuterAlt(localctx, 4)
				self.state = 103
				self.printStmt()
				pass
			elif token in [15]:
				self.enterOuterAlt(localctx, 5)
				self.state = 104
				self.returnStmt()
				pass
			elif token in [16]:
				self.enterOuterAlt(localctx, 6)
				self.state = 105
				self.whileStmt()
				pass
			elif token in [3]:
				self.enterOuterAlt(localctx, 7)
				self.state = 106
				self.block()
				pass
			else:
				raise NoViableAltException(self)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class ExprStmtContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def expression(self):
			return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_exprStmt

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterExprStmt" ):
				listener.enterExprStmt(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitExprStmt" ):
				listener.exitExprStmt(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitExprStmt" ):
				return visitor.visitExprStmt(self)
			else:
				return visitor.visitChildren(self)




	def exprStmt(self):

		localctx = CompiscriptParser.ExprStmtContext(self, self._ctx, self.state)
		self.enterRule(localctx, 12, self.RULE_exprStmt)
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 109
			self.expression()
			self.state = 110
			self.match(CompiscriptParser.T__7)
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class ForStmtContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def statement(self):
			return self.getTypedRuleContext(CompiscriptParser.StatementContext,0)


		def varDecl(self):
			return self.getTypedRuleContext(CompiscriptParser.VarDeclContext,0)


		def exprStmt(self):
			return self.getTypedRuleContext(CompiscriptParser.ExprStmtContext,0)


		def expression(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_forStmt

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterForStmt" ):
				listener.enterForStmt(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitForStmt" ):
				listener.exitForStmt(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitForStmt" ):
				return visitor.visitForStmt(self)
			else:
				return visitor.visitChildren(self)




	def forStmt(self):

		localctx = CompiscriptParser.ForStmtContext(self, self._ctx, self.state)
		self.enterRule(localctx, 14, self.RULE_forStmt)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 112
			self.match(CompiscriptParser.T__8)
			self.state = 113
			self.match(CompiscriptParser.T__9)
			self.state = 117
			self._errHandler.sync(self)
			token = self._input.LA(1)
			if token in [6]:
				self.state = 114
				self.varDecl()
				pass
			elif token in [5, 10, 26, 31, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43]:
				self.state = 115
				self.exprStmt()
				pass
			elif token in [8]:
				self.state = 116
				self.match(CompiscriptParser.T__7)
				pass
			else:
				raise NoViableAltException(self)

			self.state = 120
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17577220768800) != 0):
				self.state = 119
				self.expression()


			self.state = 122
			self.match(CompiscriptParser.T__7)
			self.state = 124
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17577220768800) != 0):
				self.state = 123
				self.expression()


			self.state = 126
			self.match(CompiscriptParser.T__10)
			self.state = 127
			self.statement()
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class IfStmtContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def expression(self):
			return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


		def statement(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.StatementContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.StatementContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_ifStmt

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterIfStmt" ):
				listener.enterIfStmt(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitIfStmt" ):
				listener.exitIfStmt(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitIfStmt" ):
				return visitor.visitIfStmt(self)
			else:
				return visitor.visitChildren(self)




	def ifStmt(self):

		localctx = CompiscriptParser.IfStmtContext(self, self._ctx, self.state)
		self.enterRule(localctx, 16, self.RULE_ifStmt)
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 129
			self.match(CompiscriptParser.T__11)
			self.state = 130
			self.match(CompiscriptParser.T__9)
			self.state = 131
			self.expression()
			self.state = 132
			self.match(CompiscriptParser.T__10)
			self.state = 133
			self.statement()
			self.state = 136
			self._errHandler.sync(self)
			la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
			if la_ == 1:
				self.state = 134
				self.match(CompiscriptParser.T__12)
				self.state = 135
				self.statement()


		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class PrintStmtContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def expression(self):
			return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_printStmt

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterPrintStmt" ):
				listener.enterPrintStmt(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitPrintStmt" ):
				listener.exitPrintStmt(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitPrintStmt" ):
				return visitor.visitPrintStmt(self)
			else:
				return visitor.visitChildren(self)




	def printStmt(self):

		localctx = CompiscriptParser.PrintStmtContext(self, self._ctx, self.state)
		self.enterRule(localctx, 18, self.RULE_printStmt)
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 138
			self.match(CompiscriptParser.T__13)
			self.state = 139
			self.expression()
			self.state = 140
			self.match(CompiscriptParser.T__7)
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class ReturnStmtContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def expression(self):
			return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_returnStmt

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterReturnStmt" ):
				listener.enterReturnStmt(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitReturnStmt" ):
				listener.exitReturnStmt(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitReturnStmt" ):
				return visitor.visitReturnStmt(self)
			else:
				return visitor.visitChildren(self)




	def returnStmt(self):

		localctx = CompiscriptParser.ReturnStmtContext(self, self._ctx, self.state)
		self.enterRule(localctx, 20, self.RULE_returnStmt)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 142
			self.match(CompiscriptParser.T__14)
			self.state = 144
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17577220768800) != 0):
				self.state = 143
				self.expression()


			self.state = 146
			self.match(CompiscriptParser.T__7)
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class WhileStmtContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def expression(self):
			return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


		def statement(self):
			return self.getTypedRuleContext(CompiscriptParser.StatementContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_whileStmt

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterWhileStmt" ):
				listener.enterWhileStmt(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitWhileStmt" ):
				listener.exitWhileStmt(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitWhileStmt" ):
				return visitor.visitWhileStmt(self)
			else:
				return visitor.visitChildren(self)




	def whileStmt(self):

		localctx = CompiscriptParser.WhileStmtContext(self, self._ctx, self.state)
		self.enterRule(localctx, 22, self.RULE_whileStmt)
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 148
			self.match(CompiscriptParser.T__15)
			self.state = 149
			self.match(CompiscriptParser.T__9)
			self.state = 150
			self.expression()
			self.state = 151
			self.match(CompiscriptParser.T__10)
			self.state = 152
			self.statement()
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class BlockContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def declaration(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.DeclarationContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.DeclarationContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_block

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterBlock" ):
				listener.enterBlock(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitBlock" ):
				listener.exitBlock(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitBlock" ):
				return visitor.visitBlock(self)
			else:
				return visitor.visitChildren(self)




	def block(self):

		localctx = CompiscriptParser.BlockContext(self, self._ctx, self.state)
		self.enterRule(localctx, 24, self.RULE_block)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 154
			self.match(CompiscriptParser.T__2)
			self.state = 158
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while (((_la) & ~0x3f) == 0 and ((1 << _la) & 17577220888170) != 0):
				self.state = 155
				self.declaration()
				self.state = 160
				self._errHandler.sync(self)
				_la = self._input.LA(1)

			self.state = 161
			self.match(CompiscriptParser.T__3)
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class FunAnonContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def block(self):
			return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


		def parameters(self):
			return self.getTypedRuleContext(CompiscriptParser.ParametersContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_funAnon

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterFunAnon" ):
				listener.enterFunAnon(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitFunAnon" ):
				listener.exitFunAnon(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitFunAnon" ):
				return visitor.visitFunAnon(self)
			else:
				return visitor.visitChildren(self)




	def funAnon(self):

		localctx = CompiscriptParser.FunAnonContext(self, self._ctx, self.state)
		self.enterRule(localctx, 26, self.RULE_funAnon)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 163
			self.match(CompiscriptParser.T__4)
			self.state = 164
			self.match(CompiscriptParser.T__9)
			self.state = 166
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			if _la==43:
				self.state = 165
				self.parameters()


			self.state = 168
			self.match(CompiscriptParser.T__10)
			self.state = 169
			self.block()
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class ExpressionContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def assignment(self):
			return self.getTypedRuleContext(CompiscriptParser.AssignmentContext,0)


		def funAnon(self):
			return self.getTypedRuleContext(CompiscriptParser.FunAnonContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_expression

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterExpression" ):
				listener.enterExpression(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitExpression" ):
				listener.exitExpression(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitExpression" ):
				return visitor.visitExpression(self)
			else:
				return visitor.visitChildren(self)




	def expression(self):

		localctx = CompiscriptParser.ExpressionContext(self, self._ctx, self.state)
		self.enterRule(localctx, 28, self.RULE_expression)
		try:
			self.state = 173
			self._errHandler.sync(self)
			la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
			if la_ == 1:
				self.enterOuterAlt(localctx, 1)
				self.state = 171
				self.assignment()
				pass

			elif la_ == 2:
				self.enterOuterAlt(localctx, 2)
				self.state = 172
				self.funAnon()
				pass


		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class AssignmentContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def IDENTIFIER(self):
			return self.getToken(CompiscriptParser.IDENTIFIER, 0)

		def assignment(self):
			return self.getTypedRuleContext(CompiscriptParser.AssignmentContext,0)


		def call(self):
			return self.getTypedRuleContext(CompiscriptParser.CallContext,0)


		def logic_or(self):
			return self.getTypedRuleContext(CompiscriptParser.Logic_orContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_assignment

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterAssignment" ):
				listener.enterAssignment(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitAssignment" ):
				listener.exitAssignment(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitAssignment" ):
				return visitor.visitAssignment(self)
			else:
				return visitor.visitChildren(self)




	def assignment(self):

		localctx = CompiscriptParser.AssignmentContext(self, self._ctx, self.state)
		self.enterRule(localctx, 30, self.RULE_assignment)
		try:
			self.state = 184
			self._errHandler.sync(self)
			la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
			if la_ == 1:
				self.enterOuterAlt(localctx, 1)
				self.state = 178
				self._errHandler.sync(self)
				la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
				if la_ == 1:
					self.state = 175
					self.call()
					self.state = 176
					self.match(CompiscriptParser.T__16)


				self.state = 180
				self.match(CompiscriptParser.IDENTIFIER)
				self.state = 181
				self.match(CompiscriptParser.T__6)
				self.state = 182
				self.assignment()
				pass

			elif la_ == 2:
				self.enterOuterAlt(localctx, 2)
				self.state = 183
				self.logic_or()
				pass


		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class Logic_orContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def logic_and(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.Logic_andContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.Logic_andContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_logic_or

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterLogic_or" ):
				listener.enterLogic_or(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitLogic_or" ):
				listener.exitLogic_or(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitLogic_or" ):
				return visitor.visitLogic_or(self)
			else:
				return visitor.visitChildren(self)




	def logic_or(self):

		localctx = CompiscriptParser.Logic_orContext(self, self._ctx, self.state)
		self.enterRule(localctx, 32, self.RULE_logic_or)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 186
			self.logic_and()
			self.state = 191
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while _la==18:
				self.state = 187
				self.match(CompiscriptParser.T__17)
				self.state = 188
				self.logic_and()
				self.state = 193
				self._errHandler.sync(self)
				_la = self._input.LA(1)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class Logic_andContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def equality(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.EqualityContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.EqualityContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_logic_and

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterLogic_and" ):
				listener.enterLogic_and(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitLogic_and" ):
				listener.exitLogic_and(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitLogic_and" ):
				return visitor.visitLogic_and(self)
			else:
				return visitor.visitChildren(self)




	def logic_and(self):

		localctx = CompiscriptParser.Logic_andContext(self, self._ctx, self.state)
		self.enterRule(localctx, 34, self.RULE_logic_and)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 194
			self.equality()
			self.state = 199
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while _la==19:
				self.state = 195
				self.match(CompiscriptParser.T__18)
				self.state = 196
				self.equality()
				self.state = 201
				self._errHandler.sync(self)
				_la = self._input.LA(1)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class EqualityContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def comparison(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.ComparisonContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.ComparisonContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_equality

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterEquality" ):
				listener.enterEquality(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitEquality" ):
				listener.exitEquality(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitEquality" ):
				return visitor.visitEquality(self)
			else:
				return visitor.visitChildren(self)




	def equality(self):

		localctx = CompiscriptParser.EqualityContext(self, self._ctx, self.state)
		self.enterRule(localctx, 36, self.RULE_equality)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 202
			self.comparison()
			self.state = 207
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while _la==20 or _la==21:
				self.state = 203
				_la = self._input.LA(1)
				if not(_la==20 or _la==21):
					self._errHandler.recoverInline(self)
				else:
					self._errHandler.reportMatch(self)
					self.consume()
				self.state = 204
				self.comparison()
				self.state = 209
				self._errHandler.sync(self)
				_la = self._input.LA(1)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class ComparisonContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def term(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.TermContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.TermContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_comparison

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterComparison" ):
				listener.enterComparison(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitComparison" ):
				listener.exitComparison(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitComparison" ):
				return visitor.visitComparison(self)
			else:
				return visitor.visitChildren(self)




	def comparison(self):

		localctx = CompiscriptParser.ComparisonContext(self, self._ctx, self.state)
		self.enterRule(localctx, 38, self.RULE_comparison)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 210
			self.term()
			self.state = 215
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while (((_la) & ~0x3f) == 0 and ((1 << _la) & 62914560) != 0):
				self.state = 211
				_la = self._input.LA(1)
				if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 62914560) != 0)):
					self._errHandler.recoverInline(self)
				else:
					self._errHandler.reportMatch(self)
					self.consume()
				self.state = 212
				self.term()
				self.state = 217
				self._errHandler.sync(self)
				_la = self._input.LA(1)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class TermContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def factor(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.FactorContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.FactorContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_term

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterTerm" ):
				listener.enterTerm(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitTerm" ):
				listener.exitTerm(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitTerm" ):
				return visitor.visitTerm(self)
			else:
				return visitor.visitChildren(self)




	def term(self):

		localctx = CompiscriptParser.TermContext(self, self._ctx, self.state)
		self.enterRule(localctx, 40, self.RULE_term)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 218
			self.factor()
			self.state = 223
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while _la==26 or _la==27:
				self.state = 219
				_la = self._input.LA(1)
				if not(_la==26 or _la==27):
					self._errHandler.recoverInline(self)
				else:
					self._errHandler.reportMatch(self)
					self.consume()
				self.state = 220
				self.factor()
				self.state = 225
				self._errHandler.sync(self)
				_la = self._input.LA(1)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class FactorContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def unary(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.UnaryContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.UnaryContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_factor

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterFactor" ):
				listener.enterFactor(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitFactor" ):
				listener.exitFactor(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitFactor" ):
				return visitor.visitFactor(self)
			else:
				return visitor.visitChildren(self)




	def factor(self):

		localctx = CompiscriptParser.FactorContext(self, self._ctx, self.state)
		self.enterRule(localctx, 42, self.RULE_factor)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 226
			self.unary()
			self.state = 231
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1879048192) != 0):
				self.state = 227
				_la = self._input.LA(1)
				if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1879048192) != 0)):
					self._errHandler.recoverInline(self)
				else:
					self._errHandler.reportMatch(self)
					self.consume()
				self.state = 228
				self.unary()
				self.state = 233
				self._errHandler.sync(self)
				_la = self._input.LA(1)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class ArrayContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def expression(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_array

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterArray" ):
				listener.enterArray(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitArray" ):
				listener.exitArray(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitArray" ):
				return visitor.visitArray(self)
			else:
				return visitor.visitChildren(self)




	def array(self):

		localctx = CompiscriptParser.ArrayContext(self, self._ctx, self.state)
		self.enterRule(localctx, 44, self.RULE_array)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 234
			self.match(CompiscriptParser.T__30)
			self.state = 243
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17577220768800) != 0):
				self.state = 235
				self.expression()
				self.state = 240
				self._errHandler.sync(self)
				_la = self._input.LA(1)
				while _la==32:
					self.state = 236
					self.match(CompiscriptParser.T__31)
					self.state = 237
					self.expression()
					self.state = 242
					self._errHandler.sync(self)
					_la = self._input.LA(1)



			self.state = 245
			self.match(CompiscriptParser.T__32)
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class InstantiationContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def IDENTIFIER(self):
			return self.getToken(CompiscriptParser.IDENTIFIER, 0)

		def arguments(self):
			return self.getTypedRuleContext(CompiscriptParser.ArgumentsContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_instantiation

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterInstantiation" ):
				listener.enterInstantiation(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitInstantiation" ):
				listener.exitInstantiation(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitInstantiation" ):
				return visitor.visitInstantiation(self)
			else:
				return visitor.visitChildren(self)




	def instantiation(self):

		localctx = CompiscriptParser.InstantiationContext(self, self._ctx, self.state)
		self.enterRule(localctx, 46, self.RULE_instantiation)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 247
			self.match(CompiscriptParser.T__33)
			self.state = 248
			self.match(CompiscriptParser.IDENTIFIER)
			self.state = 249
			self.match(CompiscriptParser.T__9)
			self.state = 251
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17577220768800) != 0):
				self.state = 250
				self.arguments()


			self.state = 253
			self.match(CompiscriptParser.T__10)
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class UnaryContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def unary(self):
			return self.getTypedRuleContext(CompiscriptParser.UnaryContext,0)


		def call(self):
			return self.getTypedRuleContext(CompiscriptParser.CallContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_unary

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterUnary" ):
				listener.enterUnary(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitUnary" ):
				listener.exitUnary(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitUnary" ):
				return visitor.visitUnary(self)
			else:
				return visitor.visitChildren(self)




	def unary(self):

		localctx = CompiscriptParser.UnaryContext(self, self._ctx, self.state)
		self.enterRule(localctx, 48, self.RULE_unary)
		self._la = 0 # Token type
		try:
			self.state = 258
			self._errHandler.sync(self)
			token = self._input.LA(1)
			if token in [26, 35]:
				self.enterOuterAlt(localctx, 1)
				self.state = 255
				_la = self._input.LA(1)
				if not(_la==26 or _la==35):
					self._errHandler.recoverInline(self)
				else:
					self._errHandler.reportMatch(self)
					self.consume()
				self.state = 256
				self.unary()
				pass
			elif token in [5, 10, 31, 34, 36, 37, 38, 39, 40, 41, 42, 43]:
				self.enterOuterAlt(localctx, 2)
				self.state = 257
				self.call()
				pass
			else:
				raise NoViableAltException(self)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class CallContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def primary(self):
			return self.getTypedRuleContext(CompiscriptParser.PrimaryContext,0)


		def IDENTIFIER(self, i:int=None):
			if i is None:
				return self.getTokens(CompiscriptParser.IDENTIFIER)
			else:
				return self.getToken(CompiscriptParser.IDENTIFIER, i)

		def expression(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


		def arguments(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.ArgumentsContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.ArgumentsContext,i)


		def funAnon(self):
			return self.getTypedRuleContext(CompiscriptParser.FunAnonContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_call

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterCall" ):
				listener.enterCall(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitCall" ):
				listener.exitCall(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitCall" ):
				return visitor.visitCall(self)
			else:
				return visitor.visitChildren(self)




	def call(self):

		localctx = CompiscriptParser.CallContext(self, self._ctx, self.state)
		self.enterRule(localctx, 50, self.RULE_call)
		self._la = 0 # Token type
		try:
			self.state = 278
			self._errHandler.sync(self)
			token = self._input.LA(1)
			if token in [10, 31, 34, 36, 37, 38, 39, 40, 41, 42, 43]:
				self.enterOuterAlt(localctx, 1)
				self.state = 260
				self.primary()
				self.state = 274
				self._errHandler.sync(self)
				_alt = self._interp.adaptivePredict(self._input,28,self._ctx)
				while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
					if _alt==1:
						self.state = 272
						self._errHandler.sync(self)
						token = self._input.LA(1)
						if token in [10]:
							self.state = 261
							self.match(CompiscriptParser.T__9)
							self.state = 263
							self._errHandler.sync(self)
							_la = self._input.LA(1)
							if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17577220768800) != 0):
								self.state = 262
								self.arguments()


							self.state = 265
							self.match(CompiscriptParser.T__10)
							pass
						elif token in [17]:
							self.state = 266
							self.match(CompiscriptParser.T__16)
							self.state = 267
							self.match(CompiscriptParser.IDENTIFIER)
							pass
						elif token in [31]:
							self.state = 268
							self.match(CompiscriptParser.T__30)
							self.state = 269
							self.expression()
							self.state = 270
							self.match(CompiscriptParser.T__32)
							pass
						else:
							raise NoViableAltException(self)
				
					self.state = 276
					self._errHandler.sync(self)
					_alt = self._interp.adaptivePredict(self._input,28,self._ctx)

				pass
			elif token in [5]:
				self.enterOuterAlt(localctx, 2)
				self.state = 277
				self.funAnon()
				pass
			else:
				raise NoViableAltException(self)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class PrimaryContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def NUMBER(self):
			return self.getToken(CompiscriptParser.NUMBER, 0)

		def STRING(self):
			return self.getToken(CompiscriptParser.STRING, 0)

		def IDENTIFIER(self):
			return self.getToken(CompiscriptParser.IDENTIFIER, 0)

		def expression(self):
			return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


		def array(self):
			return self.getTypedRuleContext(CompiscriptParser.ArrayContext,0)


		def instantiation(self):
			return self.getTypedRuleContext(CompiscriptParser.InstantiationContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_primary

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterPrimary" ):
				listener.enterPrimary(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitPrimary" ):
				listener.exitPrimary(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitPrimary" ):
				return visitor.visitPrimary(self)
			else:
				return visitor.visitChildren(self)




	def primary(self):

		localctx = CompiscriptParser.PrimaryContext(self, self._ctx, self.state)
		self.enterRule(localctx, 52, self.RULE_primary)
		try:
			self.state = 296
			self._errHandler.sync(self)
			token = self._input.LA(1)
			if token in [36]:
				self.enterOuterAlt(localctx, 1)
				self.state = 280
				self.match(CompiscriptParser.T__35)
				pass
			elif token in [37]:
				self.enterOuterAlt(localctx, 2)
				self.state = 281
				self.match(CompiscriptParser.T__36)
				pass
			elif token in [38]:
				self.enterOuterAlt(localctx, 3)
				self.state = 282
				self.match(CompiscriptParser.T__37)
				pass
			elif token in [39]:
				self.enterOuterAlt(localctx, 4)
				self.state = 283
				self.match(CompiscriptParser.T__38)
				pass
			elif token in [41]:
				self.enterOuterAlt(localctx, 5)
				self.state = 284
				self.match(CompiscriptParser.NUMBER)
				pass
			elif token in [42]:
				self.enterOuterAlt(localctx, 6)
				self.state = 285
				self.match(CompiscriptParser.STRING)
				pass
			elif token in [43]:
				self.enterOuterAlt(localctx, 7)
				self.state = 286
				self.match(CompiscriptParser.IDENTIFIER)
				pass
			elif token in [10]:
				self.enterOuterAlt(localctx, 8)
				self.state = 287
				self.match(CompiscriptParser.T__9)
				self.state = 288
				self.expression()
				self.state = 289
				self.match(CompiscriptParser.T__10)
				pass
			elif token in [40]:
				self.enterOuterAlt(localctx, 9)
				self.state = 291
				self.match(CompiscriptParser.T__39)
				self.state = 292
				self.match(CompiscriptParser.T__16)
				self.state = 293
				self.match(CompiscriptParser.IDENTIFIER)
				pass
			elif token in [31]:
				self.enterOuterAlt(localctx, 10)
				self.state = 294
				self.array()
				pass
			elif token in [34]:
				self.enterOuterAlt(localctx, 11)
				self.state = 295
				self.instantiation()
				pass
			else:
				raise NoViableAltException(self)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class FunctionContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def IDENTIFIER(self):
			return self.getToken(CompiscriptParser.IDENTIFIER, 0)

		def block(self):
			return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


		def parameters(self):
			return self.getTypedRuleContext(CompiscriptParser.ParametersContext,0)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_function

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterFunction" ):
				listener.enterFunction(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitFunction" ):
				listener.exitFunction(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitFunction" ):
				return visitor.visitFunction(self)
			else:
				return visitor.visitChildren(self)




	def function(self):

		localctx = CompiscriptParser.FunctionContext(self, self._ctx, self.state)
		self.enterRule(localctx, 54, self.RULE_function)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 298
			self.match(CompiscriptParser.IDENTIFIER)
			self.state = 299
			self.match(CompiscriptParser.T__9)
			self.state = 301
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			if _la==43:
				self.state = 300
				self.parameters()


			self.state = 303
			self.match(CompiscriptParser.T__10)
			self.state = 304
			self.block()
		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class ParametersContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def IDENTIFIER(self, i:int=None):
			if i is None:
				return self.getTokens(CompiscriptParser.IDENTIFIER)
			else:
				return self.getToken(CompiscriptParser.IDENTIFIER, i)

		def getRuleIndex(self):
			return CompiscriptParser.RULE_parameters

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterParameters" ):
				listener.enterParameters(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitParameters" ):
				listener.exitParameters(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitParameters" ):
				return visitor.visitParameters(self)
			else:
				return visitor.visitChildren(self)




	def parameters(self):

		localctx = CompiscriptParser.ParametersContext(self, self._ctx, self.state)
		self.enterRule(localctx, 56, self.RULE_parameters)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 306
			self.match(CompiscriptParser.IDENTIFIER)
			self.state = 311
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while _la==32:
				self.state = 307
				self.match(CompiscriptParser.T__31)
				self.state = 308
				self.match(CompiscriptParser.IDENTIFIER)
				self.state = 313
				self._errHandler.sync(self)
				_la = self._input.LA(1)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx


	class ArgumentsContext(ParserRuleContext):
		__slots__ = 'parser'

		def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
			super().__init__(parent, invokingState)
			self.parser = parser

		def expression(self, i:int=None):
			if i is None:
				return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
			else:
				return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


		def getRuleIndex(self):
			return CompiscriptParser.RULE_arguments

		def enterRule(self, listener:ParseTreeListener):
			if hasattr( listener, "enterArguments" ):
				listener.enterArguments(self)

		def exitRule(self, listener:ParseTreeListener):
			if hasattr( listener, "exitArguments" ):
				listener.exitArguments(self)

		def accept(self, visitor:ParseTreeVisitor):
			if hasattr( visitor, "visitArguments" ):
				return visitor.visitArguments(self)
			else:
				return visitor.visitChildren(self)




	def arguments(self):

		localctx = CompiscriptParser.ArgumentsContext(self, self._ctx, self.state)
		self.enterRule(localctx, 58, self.RULE_arguments)
		self._la = 0 # Token type
		try:
			self.enterOuterAlt(localctx, 1)
			self.state = 314
			self.expression()
			self.state = 319
			self._errHandler.sync(self)
			_la = self._input.LA(1)
			while _la==32:
				self.state = 315
				self.match(CompiscriptParser.T__31)
				self.state = 316
				self.expression()
				self.state = 321
				self._errHandler.sync(self)
				_la = self._input.LA(1)

		except RecognitionException as re:
			localctx.exception = re
			self._errHandler.reportError(self, re)
			self._errHandler.recover(self, re)
		finally:
			self.exitRule()
		return localctx